**WProofreader** is a commercial product developed and owned by WebSpellChecker LLC.

Copyright (c) 2019, WebSpellChecker LLC. All rights reserved.

In order to use WProofreader you have to purchase one of the following licenses according to your needs. You can find more about that on our website on the [pricing plan page](https://webspellchecker.com/pricing/).

Terms of Service
------------

If you are choosing WProofreader Cloud, please see the complete [Terms of Service](https://webspellchecker.com/terms-of-service/) for the Cloud services.


Software License Agreement
------------

If you are looking for a self-hosted license of WProofreader Server, please check here the complete [terms](https://docs.webspellchecker.net/display/Legal/WebSpellChecker+Software+License+Agreement) and conditions for downloading, installing and using the Server version of the WebSpellChecker software.
